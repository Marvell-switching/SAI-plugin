extern "C" {
int start_sai_thrift_rpc_server(int port);
}
